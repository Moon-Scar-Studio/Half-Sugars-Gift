namespace NebulaN.Roles.Modifier;

/// <summary>
/// Modifier「夜盲症 / Nyctalope」
/// 拥有者：在灯被真正关闭（电气破坏，Lights 基本全黑）期间，其视野按设定比例缩小。
/// 效果是“每一帧的关灯视野 × 配置值”（乘法），而非常量的“写死的视野大小”。
/// 配置项：关灯视野的乘数（默认 0 → 完全看不清；最大 1x 表示与常人无异；步长 0.25x）。
/// 仅对拥有者本人，且仅当灯已全关（非半亮/刚拉灯阶段）时生效。
///
/// 实现说明：Nebula 每帧为本地玩家计算视野时会触发 <see cref="LightRangeUpdateEvent"/>，
/// 该事件的 LightRange 每帧从 1 开始，被各 modifier 相乘。此 modifier 在该事件中，
/// 当检测到电力已基本全黑时把 LightRange 乘上配置比例，从而得到“关灯视野 × 配置”。
/// </summary>
public class Nyctalope :
    DefinedAllocatableModifierTemplate,
    DefinedAllocatableModifier,
    RuntimeAssignableGenerator<RuntimeModifier>,
    HasCitation
{
    /// <summary>
    /// 灯全关时对“每一帧视野”的乘数。范围 0 ~ 1，步长 0.25，默认 0。
    /// 效果 = 关灯视野 × 此值。0 → 完全看不见；1 → 与常人无异。
    /// </summary>
    private static FloatConfiguration darkSightOption = NebulaAPI.Configurations.Configuration(
        "options.modifier.nyctalope.darkSight",
        (0f, 1f, 0.25f),
        0f,
        FloatConfigurationDecorator.Ratio
    );

    private Nyctalope() : base(
        "nyctalope",
        "nl",
        new Virial.Color(0.31f, 0.10f, 0.45f),   // 紫色偏黑
        new IConfiguration[] { darkSightOption },
        allocateToCrewmate: true,
        allocateToImpostor: false,              // 按你的要求只给船员 + 中立
        allocateToNeutral: true
    )
    { }

    public static Nyctalope MyRole = new();

    public Citation Citation => Citations.hvtXsvc_hsg;

    public RuntimeModifier CreateInstance(GamePlayer player, int[] arguments)
        => new Instance(player);

    public class Instance : RuntimeAssignableTemplate, RuntimeModifier
    {
        /// <summary>
        /// “视为灯已全关”的开关值阈值。
        /// 灯亮度 = SwitchSystem.Value / 255（255=全亮，0=全黑）。
        /// 只在该值 ≤ 该阈值（即灯基本全黑、而不是刚拉灯还在渐渐变暗/半亮）时才套用减视。
        /// 255 * 0.08 ≈ 20（剩不到 8% 亮度 ≈ 全黑）。如需调整，改这里即可。
        /// </summary>
        private const float FullyOffValueLimit = 255f * 0.08f;

        public Instance(GamePlayer player) : base(player) { }

        DefinedModifier RuntimeModifier.Modifier => (DefinedModifier)MyRole;

        void RuntimeAssignable.OnActivated()
        {
            // 夜盲的视野收缩由 LightRangeUpdateEvent 事件驱动，激活时无需额外动作。
            // （在此占位，后续如需在激活瞬间做什么可放这里）
        }

        void RuntimeAssignable.DecorateNameConstantly(ref string name, bool canSeeAllInfo, bool inEndScene)
        {
            if (!AmOwner) return;
            name += " 夜".Color(new UnityEngine.Color(0.31f, 0.10f, 0.45f));
        }

        /// <summary>
        /// 视野更新事件：只在灯“真正全关（基本全黑）”时，把这一帧的视野乘上配置值。
        /// 即 关灯视野 × 配置项大小（乘法），而不是把它当成一个写死的视野大小。
        /// 该事件只针对本地玩家（拥有者客户端）触发，天然作用于此 modifier 的持有者。
        /// </summary>
        void OnLightRangeUpdate(Virial.Events.Game.LightRangeUpdateEvent ev)
        {
            if (!AmOwner) return;
            if (!IsLightsFullyOff()) return;
            // LightRange 每帧默认从 1 开始，这里乘上配置值 ⇒ 关灯视野 × 配置。
            ev.LightRange *= darkSightOption;
        }

        /// <summary>
        /// 判断当前本地灯的开关是否已“全关/基本全黑”。
        /// 电力 SwitchSystem 在 sabotage 启动后会从 255 一路下降；
        /// 只有当它降到不超过 <see cref="FullyOffValueLimit"/>（接近 0/全黑）时才视为真正关灯。
        /// 这样半亮/刚拉灯的过渡阶段不会被算作“关灯”。
        /// </summary>
        private static bool IsLightsFullyOff()
        {
            ShipStatus? ship = ShipStatus.Instance;
            if (ship == null) return false;

            // 供电系统(SwitchSystem)只在有该子系统的地图上存在；用线性参数读取灯开关状态。
            ISystemType? systemType = ship.Systems.ContainsKey(SystemTypes.Electrical)
                ? ship.Systems[SystemTypes.Electrical]
                : null;
            if (systemType == null) return false;

            var switchSystem = systemType.TryCast<SwitchSystem>();
            if (switchSystem == null) return false;

            return switchSystem.Value <= FullyOffValueLimit;   // ≤阈值 = 灯基本全黑
        }
    }
}
